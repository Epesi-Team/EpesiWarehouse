<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage it
 */
global $translations;
$translations['Skąpiec']='';
$translations['Ceneo']='';
$translations['Item Name']='';
$translations['Plugin']='';
$translations['Tax Rate']='';
$translations['Gross Price']='';
$translations['Compare Services']='';
$translations['Auto update']='';
$translations['eCommerce']='Commercio elettronico';
$translations['URL']='';
$translations['eCommerce - compare prices']='';
