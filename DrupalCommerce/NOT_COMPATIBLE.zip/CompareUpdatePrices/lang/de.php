<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage de
 */
global $translations;
$translations['Skąpiec']='';
$translations['Ceneo']='';
$translations['Item Name']='';
$translations['Plugin']='';
$translations['Tax Rate']='';
$translations['Gross Price']='';
$translations['Compare Services']='';
$translations['Auto update']='';
$translations['eCommerce']='';
$translations['URL']='';
$translations['eCommerce - compare prices']='';
