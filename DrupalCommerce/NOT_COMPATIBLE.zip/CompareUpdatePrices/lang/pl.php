<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pl
 */
global $translations;
$translations['Skąpiec']='';
$translations['Ceneo']='';
$translations['Item Name']='Nazwa produktu';
$translations['Plugin']='Wtyczka';
$translations['Tax Rate']='Podatek';
$translations['Gross Price']='Cena Brutto';
$translations['Compare Services']='';
$translations['Auto update']='';
$translations['eCommerce']='Sklep internetowy';
$translations['URL']='';
$translations['eCommerce - compare prices']='';
