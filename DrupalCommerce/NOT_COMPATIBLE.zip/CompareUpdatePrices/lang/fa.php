<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fa
 */
global $translations;
$translations['Skąpiec']='';
$translations['Ceneo']='';
$translations['Item Name']='';
$translations['Plugin']='نوع';
$translations['Tax Rate']='';
$translations['Gross Price']='';
$translations['Compare Services']='';
$translations['Auto update']='';
$translations['eCommerce']='تجارت الکترونیک';
$translations['URL']='';
$translations['eCommerce - compare prices']='';
