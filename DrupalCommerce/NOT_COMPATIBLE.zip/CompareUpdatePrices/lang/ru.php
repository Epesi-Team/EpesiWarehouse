<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ru
 */
global $translations;
$translations['Skąpiec']='';
$translations['Ceneo']='';
$translations['Item Name']='Наименование товара';
$translations['Plugin']='Плагин';
$translations['Tax Rate']='Ставка налога';
$translations['Gross Price']='Валовая цена';
$translations['Compare Services']='';
$translations['Auto update']='';
$translations['eCommerce']='Эл.Коммерция';
$translations['URL']='';
$translations['eCommerce - compare prices']='';
