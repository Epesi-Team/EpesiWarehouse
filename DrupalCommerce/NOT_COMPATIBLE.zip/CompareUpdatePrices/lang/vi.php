<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage vi
 */
global $translations;
$translations['Skąpiec']='';
$translations['Ceneo']='';
$translations['Item Name']='Tên sản phẩm';
$translations['Plugin']='';
$translations['Tax Rate']='Phần trăm Thuế';
$translations['Gross Price']='Giá sau Thuế';
$translations['Compare Services']='';
$translations['Auto update']='';
$translations['eCommerce']='';
$translations['URL']='';
$translations['eCommerce - compare prices']='';
