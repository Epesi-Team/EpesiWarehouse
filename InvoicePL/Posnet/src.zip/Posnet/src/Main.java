import java.applet.Applet;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.ole.win32.OLE;
import org.eclipse.swt.ole.win32.OleAutomation;
import org.eclipse.swt.ole.win32.OleControlSite;
import org.eclipse.swt.ole.win32.OleFrame;
import org.eclipse.swt.ole.win32.Variant;
import org.eclipse.swt.widgets.Display;

public class Main extends Applet {
	private static final long serialVersionUID = 2466043438967513882L;
	org.eclipse.swt.widgets.Display display;
	org.eclipse.swt.widgets.Shell swtParent;
	java.awt.Canvas awtParent;
	String ocx_path;
	OleAutomation connection;
	boolean connected = false;
	String cashier;
	int cash_id = -1;
	int trans_line = -1;
	float trans_total = 0;

	public void init() {
		Thread thread = new Thread(new Runnable() {
			public void run() {
				//register OCX
				try {
					java.io.InputStream tt = getClass().getResourceAsStream("ThermalLib.ocx");
					ocx_path = System.getProperty("java.io.tmpdir")+"\\ThermalLib.ocx";
					OutputStream os = new FileOutputStream(ocx_path);
					byte [] buf = new byte[1024];
					int num = 0;
					while((num = tt.read(buf))!=-1)
						os.write(buf,0,num);
					os.close();
					tt.close();					
					Runtime.getRuntime().exec("regsvr32 /s "+ocx_path);
					Thread.sleep(500);
				} catch (IOException e) {
					return;
				} catch (InterruptedException e) {
				}
				
				
				
				//do OLE
				setLayout(new java.awt.GridLayout(1, 1));
				awtParent = new java.awt.Canvas();
				add(awtParent);
				display = new Display();
				swtParent = org.eclipse.swt.awt.SWT_AWT.new_Shell(display,
						awtParent);
				swtParent.setLayout(new FillLayout());
				OleFrame frame = new OleFrame(swtParent,
						org.eclipse.swt.SWT.NONE);

				OleControlSite site = new OleControlSite(frame, SWT.NONE,
						"THERMALLIB.ThermalLibCtrl.1");

				setSize(1, 1);
				validate();
				site.doVerb(OLE.OLEIVERB_INPLACEACTIVATE);
				swtParent.open();
				// site.doVerb(org.eclipse.swt.ole.win32.OLE.OLEIVERB_SHOW);

				connection = new OleAutomation(site);

				while (swtParent != null && !swtParent.isDisposed()) {
					if (!display.readAndDispatch())
						display.sleep();
				}
			}
		});
		thread.start();
	}

	public void stop() {
		if (display != null && !display.isDisposed()) {
			display.syncExec(new Runnable() {
				public void run() {
					if (swtParent != null && !swtParent.isDisposed())
						swtParent.dispose();
					swtParent = null;
					display.dispose();
					display = null;
				}
			});
			remove(awtParent);
			awtParent = null;
			try {
				Runtime.getRuntime().exec("regsvr32 /u /s "+ocx_path);
			} catch (IOException e) {
			}
		}
	}
	
	public boolean OpenPort() {
		for(int i=1; i<16; i++) {
			boolean ret = OpenPort("Com"+i);
			if(ret) return true;
		}
		return false;
	}
		
	public boolean OpenPort(String com) {
		int[] ids = connection.getIDsOfNames(new String[] { "THLOpenPort" });
		Variant[] port = new Variant[] { new Variant(com) };
		int ret = connection.invoke(ids[0], port).getInt();
		if(ret==0) {
			connected = true;
			//send bell
			ids = connection.getIDsOfNames(new String[] { "THLSendBel" });
			connection.invoke(ids[0]);

			//halt on printer error
			ids = connection.getIDsOfNames(new String[] { "LBSERM" });
			Variant[] errors = new Variant[] { new Variant(2) };
			connection.invoke(ids[0],errors);

			ids = connection.getIDsOfNames(new String[] { "LBIDRQ" });
			connection.invoke(ids[0]);
			
			return true;
		}
		return false;		
	}
	
	public int ClosePort() {
		int[] ids = connection.getIDsOfNames(new String[] { "THLClosePort" });
		int ret = connection.invoke(ids[0]).getInt();
		connected = false;
		cash_id = -1;
		cashier = "";
		return ret;
	}
	
	public boolean IsOnline() {
		if(!connected) return false;
		int[] ids = connection.getIDsOfNames(new String[] { "THLSendDLE" });
		String ret = connection.invoke(ids[0]).getString();
		Pattern pattern = Pattern.compile("ONL=([01])");
		Matcher m = pattern.matcher(ret);
		if(m.find()) {
			if("1".equals(m.group(1)))
				return true;
		}
		ClosePort();
		return false;
	}

	public boolean IsPaperAcc() {
		int[] ids = connection.getIDsOfNames(new String[] { "THLSendDLE" });
		String ret = connection.invoke(ids[0]).getString();
		Pattern pattern = Pattern.compile("PE/AKK=([01])");
		Matcher m = pattern.matcher(ret);
		if(m.find()) {
			if("0".equals(m.group(1)))
				return true;
			return false;
		}
		int num = Integer.parseInt(ret);
		if(num>=-20 && num<0) ClosePort();
		else if(num!=0) System.err.println("IsPaperAcc error: "+ret);
		return false;
	}

	public boolean IsError() {
		int[] ids = connection.getIDsOfNames(new String[] { "THLSendDLE" });
		String ret = connection.invoke(ids[0]).getString();
		Pattern pattern = Pattern.compile("ERR=([01])");
		Matcher m = pattern.matcher(ret);
		if(m.find()) {
			if("1".equals(m.group(1)))
				return true;
			return false;
		}
		int num = Integer.parseInt(ret);
		if(num>=-20 && num<0) ClosePort();
		else if(num!=0) System.err.println("IsError error: "+ret);
		return true;
	}
	
	public boolean Login(String name, int number) {
		return Login(name,number,true);
	}
	
	public boolean Login(String name, int number, boolean set_on_printer) {
		if(!connected) OpenPort();
		if(set_on_printer) {
			int[] ids = connection.getIDsOfNames(new String[] { "LBLOGIN" });
			Variant[] port = new Variant[] { new Variant(name), new Variant(number) };
			int ret = connection.invoke(ids[0],port).getInt();
			if(ret!=0) {
				cashier = "";
				cash_id = -1;
				if(ret>=-20 && ret<0) ClosePort();
				else if(ret!=0) System.err.println("Login error: "+ret);
				return false;
			}
		}
		cashier = name;
		cash_id = number;
		return true;
	}

	public boolean Logout(String name, int number) {
		cashier = "";
		cash_id = -1;
		int[] ids = connection.getIDsOfNames(new String[] { "LBLOGOUT" });
		Variant[] port = new Variant[] { new Variant(name), new Variant(number) };
		int ret = connection.invoke(ids[0],port).getInt();
		if(ret<0 && ret>=-20) ClosePort();
		else if(ret!=0) System.err.println("Logout error: "+ret);
		return ret==0;
	}
	
	public boolean BeginTrans() {
		if(cash_id==-1) return false;
		int[] ids = connection.getIDsOfNames(new String[] { "LBTRSHDR" });
		Variant[] port = new Variant[] { new Variant(0), new Variant(0), new Variant(""), new Variant(""), new Variant("") };
		int ret = connection.invoke(ids[0],port).getInt();
		if(ret!=0) {
			if(ret<0 && ret>=-20) ClosePort();
			else if(ret!=0) System.err.println("BeginTrans error: "+ret);
			trans_line = -1;
			return false;
		}
		trans_line = 1;
		trans_total = 0;
		return true;
	}

	public boolean CancelTrans() {
		return CancelTrans("");
	}
	
	public boolean CancelTrans(String trans_id) {
		if(cash_id==-1) return false;
		trans_line = -1;
		trans_total = 0;
		int[] ids = connection.getIDsOfNames(new String[] { "LBTREXITCAN" });
		Variant[] port = new Variant[] { new Variant(trans_id.equals("")?0:1), new Variant(cash_id), new Variant(cashier), new Variant(trans_id) };
		int ret = connection.invoke(ids[0],port).getInt();
		if(ret<0 && ret>=-20) ClosePort();
		else if(ret!=0) System.err.println("CancelTrans error: "+ret);
		return ret==0;	
	}
	
	public boolean CommitTrans(float cash_amount) {
		return CommitTrans(cash_amount,"");
	}

	public boolean CommitTrans(float cash_amount, String trans_id) {
		return CommitTrans(cash_amount,trans_id,"");
	}

	public boolean CommitTrans(float cash_amount, String trans_id, String description) {
		String cashier_code = (new Integer(cash_id)).toString()+cashier.substring(0, 2);
		return CommitTrans(cash_amount,trans_id,description,cashier_code);
	}

	public boolean CommitTrans(float cash_amount, String trans_id, String description,String cashier_code) {
		return CommitTrans(cash_amount,trans_id,description,cashier_code,0,0);
	}

	public boolean CommitTrans(float cash_amount, String trans_id, String description, String cashier_code, int discount_type, float discount_amount) {
		if(cash_id==-1) return false;
		int[] ids = connection.getIDsOfNames(new String[] { "LBTREXIT" });
		Variant[] port = new Variant[] { new Variant(0), new Variant(trans_id.equals("")?0:(description.equals("")?1:2)), new Variant(discount_type), new Variant(cashier_code), new Variant(trans_id), new Variant(description), new Variant(""), new Variant(cash_amount), new Variant(trans_total), new Variant(discount_amount) };
		int ret = connection.invoke(ids[0],port).getInt();
		if(ret<0 && ret>=-20) ClosePort();
		else if(ret!=0) System.err.println("CommitTrans error: "+ret);
		trans_line = -1;
		trans_total = 0;
		return ret==0;		
	}

	public boolean AddItemToTrans(String name, float amount, float price, String ptu) {
		return AddItemToTrans(name,amount,price,ptu,0,0,"",false);
	}

	public boolean AddItemToTrans(String name, float amount, float price, String ptu, int discount_type, float discount_amount, String discount_description) {
		return AddItemToTrans(name,amount,price,ptu,discount_type,discount_amount,discount_description,false);
	}
	
	public boolean DelItemFromTrans(String name, float amount, float price, String ptu) {
		return AddItemToTrans(name,amount,price,ptu,0,0,"",true);
	}

	public boolean DelItemFromTrans(String name, float amount, float price, String ptu, int discount_type, float discount_amount, String discount_description) {
		return AddItemToTrans(name,amount,price,ptu,discount_type,discount_amount,discount_description,true);
	}

	public boolean AddItemToTrans(String name, float amount, float price, String ptu, int discount_type, float discount_amount, String discount_description, boolean storno) {
		if(cash_id==-1) return false;
		if(trans_line<=0 && !BeginTrans()) return false;		
		int[] ids = connection.getIDsOfNames(new String[] { "LBTRSLN" });
		Variant[] port = new Variant[] { new Variant(storno?0:trans_line), new Variant(discount_type), new Variant(discount_description.equals("")?0:16), new Variant(name), new Variant(amount), new Variant(ptu), new Variant(price), new Variant(amount*price), new Variant(discount_amount), new Variant(discount_description) };
		int ret = connection.invoke(ids[0],port).getInt();
		if(ret!=0) {
			CancelTrans();
			if(ret<0 && ret>=-20) ClosePort();
			else if(ret!=0) System.err.println("AddItemToTrans error: "+ret);
			return false;
		}
		float t = amount*price;
		switch(discount_type) {
		case 0: //brak rabatu
			break;
		case 1: //rabat kwotowy
			t -= discount_amount;
			break;
		case 2: //rabat procentowy
			t -= t*discount_amount/100;
			break;
		case 3: //narzut kwotowy
			t += discount_amount;
			break;
		case 4: //narzut procentowy
			t += t*discount_amount/100;
			break;
		}
		if(storno) t = -t; //odejmij od total
		trans_total += t;
		trans_line++;
		return true;			
	}
	
	/*

	    java.lang.String thlReceive();

	    int thlSend(
	        java.lang.String body,
	        short frame,
	        short crc);

	    java.lang.String lbsendck();

	    java.lang.String thlSendDLE();

	    java.lang.String thlSendENQ();

	    int thlSendCAN();

	    int lbsndmd(
	        short value);

	    int lbdsp(
	        short value,
	        java.lang.String line1,
	        java.lang.String line2);

	    int lbdspline(
	        short value,
	        java.lang.String napis);

	    int lbfeed(
	        short value);

	    int lblogin(
	        java.lang.String kasjer,
	        java.lang.String nr_kasy);

	    int lblogout(
	        java.lang.String kasjer,
	        java.lang.String nr_kasy);

	    int lbtrshdr(
	        short value1,
	        short value2,
	        java.lang.String linia1,
	        java.lang.String linia2,
	        java.lang.String linia3);

	    int lbtrsln(
	        short pi,
	        short pr,
	        short po,
	        java.lang.String nazwa,
	        java.lang.String ilosc,
	        java.lang.String ptu,
	        java.lang.String cena,
	        java.lang.String brutto,
	        java.lang.String rabat,
	        java.lang.String opis_Rabatu);

	    int lbtrexitcan(
	        short pns,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer,
	        java.lang.String nr_systemowy);

	    int lbtrexit(
	        short pr,
	        short pn,
	        short px,
	        java.lang.String kod,
	        java.lang.String linia1,
	        java.lang.String linia2,
	        java.lang.String linia3,
	        java.lang.String wplata,
	        java.lang.String total,
	        java.lang.String rabat);

	    int thlSetCk(
	        java.lang.String godzina,
	        java.lang.String minuta,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    int lbstocsh(
	        java.lang.String wyplata,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    int lbdeccsh(
	        java.lang.String wyplata,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    int lbinccsh(
	        java.lang.String wplata,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    int lbserm(
	        short value);

	    int lbernrq();

	    int lbdayrep(
	        int timeout,
	        short value,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    java.lang.String lbfstrq(
	        short value);

	    int lbcshsts(
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    int lbfskreP1(
	        short pt,
	        java.lang.String dataPoczatkowa,
	        java.lang.String dataKoncowa,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    int lbfskreP2(
	        short pt,
	        short od,
	        short _do,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    int thlCleanComBuf();

	    java.lang.String lbidrq();

	    int lbtrxenD1(
	        short pns,
	        short pr,
	        short pg,
	        java.lang.String nr_sys,
	        java.lang.String total,
	        java.lang.String wplata,
	        java.lang.String reszta,
	        java.lang.String nr_kasy,
	        java.lang.String kasjer);

	    int thlAddFormPlat(
	        short pfx,
	        java.lang.String nazwa,
	        java.lang.String wartosc);

	    int lbdep(
	        short ps,
	        java.lang.String nr,
	        java.lang.String ilosc,
	        java.lang.String wartosc);

	    int thlAddKaucje(
	        short ps,
	        java.lang.String nr,
	        java.lang.String ilosc,
	        java.lang.String wartosc);

	    int thlAddRab(
	        short px,
	        short pxs,
	        java.lang.String wartosc,
	        java.lang.String opis_Rabatu);

	    int lbcshreP1(
	        java.lang.String zmiana,
	        java.lang.String kasjer,
	        java.lang.String poszatek,
	        java.lang.String koniec,
	        java.lang.String przychod,
	        java.lang.String sprzeD_GOTOWKA,
	        java.lang.String wplaty,
	        java.lang.String przyjecia,
	        java.lang.String wyplaty,
	        java.lang.String wydania,
	        java.lang.String staN_KASY,
	        java.lang.String il_parag,
	        java.lang.String il_anul,
	        java.lang.String il_storno,
	        java.lang.String nr_kasy);

	    int thlAddCshRepFormPlat(
	        short ps,
	        java.lang.String nazwa,
	        java.lang.String wartosc);

	    int lbfstrQ25(
	        short py,
	        short pm,
	        short pd,
	        short ph,
	        short pmin);

	    int lbfstrQ26(
	        short nr);

	    int thermalLibGetVersion();

	    int thlOpenPortEx(
	        boolean flowControl,
	        java.lang.String portName,
	        int baudRate);

	    int thlOpenPortEx2(
	        boolean flowControl,
	        java.lang.String portName,
	        int baudRate,
	        boolean lbserm);

	    int thlSendFile(
	        java.lang.String fileName);

	    java.lang.String thlReceiveAll(
	        int timeout);

	    int thlAddLines(
	        short pn,
	        java.lang.String line1,
	        java.lang.String line2,
	        java.lang.String line3);*/	
}